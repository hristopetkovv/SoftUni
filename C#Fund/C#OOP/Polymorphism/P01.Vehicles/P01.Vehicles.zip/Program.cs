﻿using P01.Vehicles.Models;
using System;

namespace P01.Vehicles
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] carArgs = Console.ReadLine().Split();

            double carFuelQuantity = double.Parse(carArgs[1]);
            double carFuelConsupmtion = double.Parse(carArgs[2]);
            int carTankCapacity = int.Parse(carArgs[3]);

            Car car = new Car(carFuelQuantity,carFuelConsupmtion, carTankCapacity);

            string[] truckArgs = Console.ReadLine().Split();

            double truckFuelQuantity = double.Parse(truckArgs[1]);
            double truckFuelConsupmtion = double.Parse(truckArgs[2]);
            int truckTankCapacity = int.Parse(truckArgs[3]);

            Truck truck = new Truck(truckFuelQuantity,truckFuelConsupmtion, truckTankCapacity);

            string[] busArgs = Console.ReadLine().Split();

            double busFuelQuantity = double.Parse(busArgs[1]);
            double busFuelConsupmtion = double.Parse(busArgs[2]);
            int busTankCapacity = int.Parse(busArgs[3]);

            Bus bus = new Bus(busFuelQuantity, busFuelConsupmtion, busTankCapacity);

            int commandsCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < commandsCount; i++)
            {
                string[] commandArgs = Console.ReadLine().Split();

                string command = commandArgs[0];
                string commandType = commandArgs[1];

                if (command == "Drive")
                {
                    double distance = double.Parse(commandArgs[2]);

                    if (commandType == "Car")
                    {
                        Console.WriteLine(car.Drive(distance));
                    }
                    else if (commandType == "Truck")
                    {
                        Console.WriteLine(truck.Drive(distance));
                    }
                    else
                    {
                        Console.WriteLine(bus.Drive(distance));
                    }
                }
                else if (command == "Refuel")
                {
                    double fuelAmount = double.Parse(commandArgs[2]);

                    try
                    {

                        if (commandType == "Car")
                        {
                            car.Refuel(fuelAmount);
                        }
                        else if (commandType == "Truck")
                        {
                            truck.Refuel(fuelAmount);
                        }
                        else
                        {
                            bus.Refuel(fuelAmount);
                        }
                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.Message);
                    }
                }
                else
                {
                    double distance = double.Parse(commandArgs[2]);
                    Console.WriteLine(bus.DriveEmpty(distance));
                }
            }

            Console.WriteLine(car);
            Console.WriteLine(truck);
            Console.WriteLine(bus);
        }
    }
}
