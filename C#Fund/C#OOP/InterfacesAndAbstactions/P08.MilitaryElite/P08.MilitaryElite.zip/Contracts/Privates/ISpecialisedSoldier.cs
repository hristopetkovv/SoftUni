﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P08.MilitaryElite.Contracts.Privates
{
    public interface ISpecialisedSoldier
    {
        string Corps { get; }
    }
}
