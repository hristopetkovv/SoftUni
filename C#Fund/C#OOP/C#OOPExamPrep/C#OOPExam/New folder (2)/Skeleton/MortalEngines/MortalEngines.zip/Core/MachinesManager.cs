﻿namespace MortalEngines.Core
{
    using Contracts;
    using MortalEngines.Common;
    using MortalEngines.Entities.Contracts;
    using MortalEngines.Entities.Factories;
    using System.Collections.Generic;
    using System.Linq;

    public class MachinesManager : IMachinesManager
    {
        private PilotFactory pilotFactory;
        private FighterFactory fighterFactory;
        private TankFactory tankFactory;
        private IList<string> pilots;
        private IList<IFighter> fighters;
        private IList<ITank> tanks;
        private IList<string> machines;

        public MachinesManager()
        {
            this.pilotFactory = new PilotFactory();
            this.tankFactory = new TankFactory();
            this.fighterFactory = new FighterFactory();
            this.pilots = new List<string>();
            this.fighters = new List<IFighter>();
            this.tanks = new List<ITank>();
            this.machines = new List<string>();
        }

        public string HirePilot(string name)
        {
            IPilot pilot = this.pilotFactory.CreatePilot(name);
            string message = "";
            if(!pilots.Contains(name))
            {
                this.pilots.Add(name);

                message = $"Pilot {name} hired";

                
            }
            else
            {
                message = $"Pilot {name} is hired already";
            }

            return message;
        }

        public string ManufactureTank(string name, double attackPoints, double defensePoints)
        {
            ITank tank = this.tankFactory.CreateTank(name, attackPoints, defensePoints);

            this.machines.Add(name);

            string message = "";

            if(tanks.Contains(tank))
            {
                message = $"Machine {name} is manufactured already";
            }
            else
            {
                this.tanks.Add(tank);

                message= $"Tank {name} manufactured - attack: {attackPoints}; defense: {defensePoints}";
            }

            return message;
        }

        public string ManufactureFighter(string name, double attackPoints, double defensePoints)
        {
            IFighter fighter = this.fighterFactory.CreateFighter(name, attackPoints, defensePoints);

            this.machines.Add(name);

            string message = "";

            if(fighters.Contains(fighter))
            {
                message = $"Machine {name} is manufactured already";
            }
            else
            {
                this.fighters.Add(fighter);

                message = $"Fighter {name} manufactured - attack: {attackPoints}; defense: {defensePoints}; aggressive: ON";
            }

            return message;       
        }

        public string EngageMachine(string selectedPilotName, string selectedMachineName)
        {
            string message = "";

            if(!pilots.Contains(selectedPilotName))
            {
                message = $"Pilot {selectedPilotName} could not be found";
            }
            
            else if(!machines.Contains(selectedMachineName))
            {
                message = $"Machine {selectedMachineName} could not be found";
            }

            else
            {

            }
            return message;
        }

        public string AttackMachines(string attackingMachineName, string defendingMachineName)
        {
            throw new System.NotImplementedException();
        }

        public string PilotReport(string pilotReporting)
        {
            throw new System.NotImplementedException();
        }

        public string MachineReport(string machineName)
        {
            throw new System.NotImplementedException();
        }

        public string ToggleFighterAggressiveMode(string fighterName)
        {
            throw new System.NotImplementedException();
        }

        public string ToggleTankDefenseMode(string tankName)
        {
            throw new System.NotImplementedException();
        }
    }
}