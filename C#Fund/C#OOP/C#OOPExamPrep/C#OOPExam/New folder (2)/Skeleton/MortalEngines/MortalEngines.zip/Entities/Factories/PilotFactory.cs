﻿using MortalEngines.Entities.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace MortalEngines.Entities.Factories
{
    public class PilotFactory
    {
        public IPilot CreatePilot(string name)
        {
            Type type = Assembly.GetCallingAssembly()
                                .GetTypes()
                                .FirstOrDefault(t => t.Name == name);

            IPilot pilot = (IPilot)Activator.CreateInstance(type);

            return pilot;

        }
    }
}
