﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MortalEngines.Entities.Contracts
{
    public class Fighter : BaseMachine, IFighter
    {
        private const double initialHealthPoints = 200;

        public Fighter(string name, double attackPoints, double defensePoints) 
            : base(name, attackPoints, defensePoints, initialHealthPoints)
        {
            this.AggressiveMode = true;
        }

        public bool AggressiveMode { get; set; }

        public void ToggleAggressiveMode()
        {
            if(AggressiveMode == true)
            {
                AttackPoints += 50;
                DefensePoints -= 25;
            }
            else
            {
                AttackPoints -= 50;
                DefensePoints += 25;
            }
        }

        public override string ToString()
        {
            string agressiveCommand = "";

            if(AggressiveMode==false)
            {
                agressiveCommand = "OFF";
            }
            else
            {
                agressiveCommand = "ON";
            }

            return $" *Aggressive: {agressiveCommand}";
        }
    }
}
