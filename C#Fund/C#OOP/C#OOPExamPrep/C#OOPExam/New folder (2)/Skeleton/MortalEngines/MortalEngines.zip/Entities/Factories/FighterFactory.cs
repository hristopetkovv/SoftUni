﻿using MortalEngines.Entities.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace MortalEngines.Entities.Factories
{
    public class FighterFactory
    {
        public IFighter CreateFighter(string name, double attackPoints, double defensePoints)
        {
            Type type = Assembly.GetCallingAssembly()
                                .GetTypes()
                                .FirstOrDefault(t => t.Name == name);

            IFighter fighter = (IFighter)Activator.CreateInstance(type);

            return fighter;

        }
    }
}
