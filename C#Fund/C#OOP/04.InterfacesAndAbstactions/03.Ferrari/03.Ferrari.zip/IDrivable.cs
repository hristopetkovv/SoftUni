﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Ferrari
{
    public interface IDrivable
    {
        string Brakes();

        string Gas();
    }
}
