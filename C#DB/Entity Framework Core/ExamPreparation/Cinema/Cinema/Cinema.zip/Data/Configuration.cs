﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=I4KOWE\SQLEXPRESS;Database=Cinema;Trusted_Connection=True";
    }
}
